Please refer to the nnAudio homepage 
[Github-flavored Markdown](https://github.com/KinWaiCheuk/nnAudio)